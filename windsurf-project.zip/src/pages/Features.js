import { FeaturesGrid } from '../components/FeaturesGrid.js'

export function FeaturesPage() {
  return `
    <main>
      ${FeaturesGrid()}
    </main>
  `
}
